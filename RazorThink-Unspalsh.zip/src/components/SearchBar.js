import React from "react";

export default class SearchBar extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      term: ""
    };
  }

  onInputChangeUnboundThis = (event) => {
    console.log("THIS", this); 
    console.log("EVENT VALUE", event.target.value);
    this.setState({
      term: event.target.value
    });
  }

  onInputChangeBoundThis = event => {
    console.log("THIS", this);
    console.log("EVENT VALUE", event.target.value);
    this.setState({
      term: event.target.value
    });
  };

  onFormSubmit = event => {
    event.preventDefault();
    this.props.handleSearchWithTerm(this.state.term);
  };

  render() {
    return (
      <div className="ui segment">
        <form className="ui form" onSubmit={this.onFormSubmit}>
          <div className="field">
            <label>Image Search</label>
            <input
              value={this.state.term}
              type="text"
              onChange={this.onInputChangeBoundThis}
            />
          </div>
        </form>
      </div>
    );
  }
}
